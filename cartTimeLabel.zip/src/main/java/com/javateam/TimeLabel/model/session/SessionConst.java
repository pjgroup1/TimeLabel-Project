package com.javateam.TimeLabel.model.session;

public class SessionConst {
    public static final String LOGIN_USER = "loginUser";

}
