package com.javateam.TimeLabel.service.dto;

import lombok.Data;

@Data
public class UserLoginServiceDTO {

    private Long userNo;
 
    private String userId;
    
    private String userPw;

}
